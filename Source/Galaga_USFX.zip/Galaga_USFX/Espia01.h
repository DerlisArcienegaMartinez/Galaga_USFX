// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "NaveEnemigaEspia.h"
#include "Espia01.generated.h"

/**
 * 
 */
UCLASS()
class GALAGA_USFX_API AEspia01 : public ANaveEnemigaEspia
{
	GENERATED_BODY()
	
};
